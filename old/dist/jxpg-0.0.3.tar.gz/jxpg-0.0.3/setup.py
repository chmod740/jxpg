from setuptools import setup

setup(
    name='jxpg',
    version='0.0.3',
    description='',
    author='hupeng',
    author_email='hupeng@imudges.com',
    url='',
    packages=['jxpg'],
    include_package_data=True,
    install_requires=['httplib2>=0.9'],
    license='MIT License',
    zip_safe=False,
)